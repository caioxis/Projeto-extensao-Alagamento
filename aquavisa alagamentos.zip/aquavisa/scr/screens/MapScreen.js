import { View, Text } from 'react-native';

export default function MapScreen() {
  return (
    <View>
      <Text>MAPA</Text>
    </View>
  );
}