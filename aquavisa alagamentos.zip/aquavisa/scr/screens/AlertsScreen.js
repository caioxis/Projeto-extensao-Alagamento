import { View, Text } from 'react-native';

export default function AlertsScreen() {
  return (
    <View>
      <Text>ALERTAS</Text>
    </View>
  );
}