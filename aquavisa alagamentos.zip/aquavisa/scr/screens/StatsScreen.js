import { View, Text } from 'react-native';

export default function StatsScreen() {
  return (
    <View>
      <Text>ESTATÍSTICAS</Text>
    </View>
  );
}